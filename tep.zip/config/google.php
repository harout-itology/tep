<?php


return [
    'setApplicationName' => 'tep-v1',
    'setClientId' => '16239107095-v6k36cujp6oqpapub0dmj1dlet6k6tb5.apps.googleusercontent.com',
    'setClientSecret' => 'cRC4G9aB2kMX_T2HMla-xGCq',
    'setDeveloperKey' => 'AIzaSyAFW6ifz4HBeEU1-ZDHUgSd8eC_Krq8eB4',
    'google_redirect_url' => 'google-oauth2callback',
    'googleSetScopes' => [
        'https://www.googleapis.com/auth/plus.me',
        'https://www.googleapis.com/auth/userinfo.email',
        'https://www.googleapis.com/auth/userinfo.profile',
    ]
];