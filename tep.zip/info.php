<?php  phpinfo() ;

