<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container login">
        <div class="row vertical-offset">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="col-md-6 text-center">
                            <div class="row">
                                <div class="col-md-12">
									<br><img src="<?php echo e(url('/public/img/logo.png')); ?>"  width="100"/><br><br>
									<a href="<?php echo e(url('/')); ?>">Back to Home</a>
								</div>                                
                            </div>
                        </div>
						<div class="col-md-6 text-center">
                            <div class="row">
                                <div class="col-md-12"><img src="<?php echo e(url('/public/img/404.png')); ?>"  width="250"/></div>                                
                            </div>
                        </div>            
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>