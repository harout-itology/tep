<?php $__env->startSection('head'); ?>
    <style>
        body{
            background-image: none;
        }  		
    </style>
	<link rel="stylesheet" href="<?php echo e(url('public/jquery/dataTables.min.css')); ?>" >
	<link rel="stylesheet" href="<?php echo e(url('public/jquery/buttons.dataTables.min.css')); ?>" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" style="width: 100%">
        <div class="row  ">
		
            <div class="col-md-10 main-bar">						
                <div id="main" class="panel panel-default">
                    <div class="panel-body">											
						<?php if( session('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>
						<form class="search navbar navbar-default mobile" method='get' action='' onsubmit="return my_submit()">											
							<input class="" type='text' placeholder='Latitude' name='latitude' value="<?php echo e($r_latitude==41.949101 ? '' : $r_latitude); ?>" >
							<input class="" type='text' placeholder='Longitude' name='longitude' value="<?php echo e($r_longitude==-101.148345 ? '' : $r_longitude); ?>" >
							<input class="" type='text' placeholder='Radius Mi' name='radius' value="<?php echo e($r_radius==10000 ? '' : $r_radius); ?>" >
							<select class="" name='towerowner[]'  >
								<option value='all'>All Owners</option>
								<?php $__currentLoopData = $towerowner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option <?php echo e($r_towerowner[0]==$item ? 'selected' : ''); ?> value='<?php echo e($item); ?>'><?php echo e($item); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<button class="submit" type='submit'>Search</button>
							<i class="btn btn-primary menu-open fa fa-arrow-left" aria-hidden="true" style='display:none'></i>
						</form>						
						<ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#menu1"><i class="fa fa-bars" aria-hidden="true"></i> &nbsp;  List View</a></li>
                            <li><a data-toggle="tab" href="#menu2"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp; Map View</a></li>
                        </ul><br>
                        <div class="tab-content">
                            <div id="menu1" class="tab-pane fade in active ">
                                <table id="example" class="display nowrap" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>Map</th>
										<th>Tower ID</th>
                                        <th>Site Name</th>
                                        <th>Address</th>
                                        <th>City</th>
                                        <th>Country</th>
										<th>State</th>
                                        <th>Height</th>
                                        <th>Infication</th>
                                        <th>Owner</th>
                                    </tr>
                                    </thead>                                    
                                    <tbody>
                                    <?php $__currentLoopData = $towers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
										<td><i title=' Show Map ' data-id="<?php echo e($item->towerid); ?>" data-co1="<?php echo e($item->latitude); ?>" data-co2="<?php echo e($item->longitude); ?>"  class="btn fa fa-map-marker open-model" aria-hidden="true"  ></i> </td>
										<td><a title=' Click to Edit ' href="<?php echo e(url('tower/'.$item->id.'/edit')); ?>" ><?php echo e($item->towerid); ?></a></td>
                                        <td><?php echo e($item->sitename); ?></td>
                                        <td><?php echo e($item->address); ?></td>
                                        <td><?php echo e($item->city); ?></td>
                                        <td><?php echo e($item->country); ?></td>
										<td><?php echo e($item->state); ?></td>
                                        <td><?php echo e($item->height); ?></td>
                                        <td><?php echo e($item->infication); ?></td>
                                        <td><?php echo e($item->towerowner); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
								<div class='col-md-6' style='padding:10px 0'>Showing   <?php echo e($towers->total()); ?> Entries
								</div>
								<div class='col-md-6' ><div class='pull-right' ><?php echo e($towers->appends(request()->input())->links()); ?></div></div>
                            </div>
                            <div id="menu2" class="tab-pane fade">
                                <div id="map"></div>
                            </div>
                        </div>						
					</div>
                </div>            
			</div>
			
			<div class="col-md-2 menu-close-bar mobile">
				<form  method='get' action='' id="form_filter">
				<input type='hidden' name='type' id='type' >
				<div class="panel-group pre-scrollable" id="accordion" style='min-height:500px'>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
							  <i class="btn menu-close fa fa-times pull-right" aria-hidden="true" style='margin-top:-5px'></i>
							  <b>Filters List</b>
							</h4>
					    </div>
					</div>						
					<div class="panel panel-default">
					  <div class="panel-heading">
						<h4 class="panel-title">
						  <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">City</a>
						</h4>
					  </div>
					  <div id="collapse1" class="panel-collapse collapse <?php echo e($type=='city' || $type=='' ? 'in' : ''); ?>    ">
						<div class="panel-body">
								<ul class="list-group list-unstyled">   
									<li >
										<?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($item): ?>
												<div class="checkbox checkbox-primary">
													<input class='filter' id="city_<?php echo e($item); ?>" name="city[]" <?php echo e(isset($r_city) ? in_array($item,$r_city) ? 'checked' : '' : 'checked'); ?> type="checkbox" value="<?php echo e($item); ?>" >
													<label for="city_<?php echo e($item); ?>"><?php echo e($item); ?></label>
												</div>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</li>                                							
								</ul>
						</div>
					  </div>
					</div>					
					<div class="panel panel-default">
					  <div class="panel-heading">
						<h4 class="panel-title">
						  <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Country</a>
						</h4>
					  </div>
					  <div id="collapse2" class="panel-collapse collapse <?php echo e($type=='country' ? 'in' : ''); ?>">
						<div class="panel-body">
								<ul class="list-group list-unstyled">   
									<li >
										<?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="checkbox checkbox-primary">
												<input class='filter'  id="country_<?php echo e($item); ?>" name="country[]" <?php echo e(isset($r_country) ? in_array($item,$r_country) ? 'checked' : '' : 'checked'); ?>  type="checkbox" value="<?php echo e($item); ?>" >
												<label for="country_<?php echo e($item); ?>"><?php echo e($item); ?></label>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</li>                                							
								</ul>
						</div>
					  </div>
					</div>					
					<div class="panel panel-default">
					  <div class="panel-heading">
						<h4 class="panel-title">
						  <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">State</a>
						</h4>
					  </div>
					  <div id="collapse3" class="panel-collapse collapse <?php echo e($type=='state' ? 'in' : ''); ?>">
						<div class="panel-body">
								<ul class="list-group list-unstyled">   
									<li >
										<?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="checkbox checkbox-primary">
												<input class='filter'  id="state_<?php echo e($item); ?>" name="state[]" <?php echo e(isset($r_state) ? in_array($item,$r_state) ? 'checked' : '' : 'checked'); ?> type="checkbox" value="<?php echo e($item); ?>" >
												<label for="state_<?php echo e($item); ?>"><?php echo e($item); ?></label>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</li>                                							
								</ul>
						</div>
					  </div>
					</div>					
					<div class="panel panel-default">
					  <div class="panel-heading">
						<h4 class="panel-title">
						  <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Infication</a>
						</h4>
					  </div>
					  <div id="collapse4" class="panel-collapse collapse <?php echo e($type=='infication' ? 'in' : ''); ?>">
						<div class="panel-body">
								<ul class="list-group list-unstyled">   
									<li >
										<?php $__currentLoopData = $infication; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($item): ?>
												<div class="checkbox checkbox-primary">
													<input class='filter' id="infication_<?php echo e($item); ?>" name="infication[]" type="checkbox" <?php echo e(isset($r_infication) ? in_array($item,$r_infication) ? 'checked' : '' : 'checked'); ?> value="<?php echo e($item); ?>" >
													<label for="infication_<?php echo e($item); ?>"><?php echo e($item); ?></label>
												</div>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</li>                                							
								</ul>
						</div>
					  </div>
					</div>					
				</div>
				</form>
			</div>
			
        </div>
    </div>
	
	<!-- Modal -->
	<div id="myModal" class="modal fade" role="dialog">
	  <div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title"></h4>
		  </div>
		  <div class="modal-body">
			<div id='model-map'></div>
		  </div>		  
		</div>

	  </div>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    <script src="<?php echo e(url('public/jquery/dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/jquery/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/jquery/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/jquery/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/jquery/buttons.print.min.js')); ?>"></script>
	<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($google_api); ?>&callback=initMap"></script>

    <script>
		//  show loading
		function my_submit(){
			$(".se-pre-con").fadeIn();			
		}
		$('.pagination li').on('click', function () {
			$(".se-pre-con").fadeIn();	
		});
		
		// bootstrap model
		$(function(){
		  $(".open-model").click(function(){      
			 $("#myModal").modal("show");
			 $('.modal-title').html($(this).data('id'));	
			 var x= $(this).data('co1');
			 var y= $(this).data('co2');
			 $('#model-map').html('<iframe width="100%" height="400" id="gmap_canvas" src="https://maps.google.com/maps?q='+x+','+y+'&z=5&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>');	
		  });
		});
		// filter click
		$('.filter').on('click', function () {
			$('#type').val($(this).attr('id'));
			$(".se-pre-con").fadeIn();
			$('#form_filter').submit();
		});
		// close the right
		$('.menu-close').on('click', function () {
			$('.menu-open').show();
			$('.menu-close-bar').hide();
			$('.main-bar').removeClass('col-md-10').addClass('col-md-12');
			table.fnDraw();
        });
		// open the right	
		$('.menu-open').on('click', function () {
			$('.menu-open').hide();
			$('.menu-close-bar').show();
			$('.main-bar').removeClass('col-md-12').addClass('col-md-10');
			table.fnDraw();
        });	
		// data table        
        var table = $('#example').dataTable( {	
			 "scrollY":        "290px",
            dom: '<"top"Bf>rt<"bottom">',
            "scrollX": true,
            buttons: [ 'colvis', 'print' ]
        });		
        $('.dt-button').addClass('btn btn-default').removeClass('dt-button');
		// google map
        var map;
        function initMap() {
            map = new google.maps.Map(document.getElementById('map'), {
                zoom: 5,
                mapTypeId: 'terrain'
            });					
            // Create a <script> tag and set the USGS URL as the source.
            var script = document.createElement('script');
            // This example uses a local copy of the GeoJSON stored at  // http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojsonp
            script.src = 'https://developers.google.com/maps/documentation/javascript/examples/json/earthquake_GeoJSONP.js';
            document.getElementsByTagName('head')[0].appendChild(script);
        }
        // Loop through the results array and place a marker for each // set of coordinates.
        window.eqfeed_callback = function(results) {
           <?php $__currentLoopData = $towers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                var latLng = new google.maps.LatLng(<?php echo e($item->latitude); ?>,<?php echo e($item->longitude); ?>);
                var marker = new google.maps.Marker({
                    position: latLng,
                    map: map
                });
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		   
        }
		// tabs on change google map activation
        $('.nav-tabs').on('shown.bs.tab', function () {
            google.maps.event.trigger(map, 'resize');
            map.setCenter(new google.maps.LatLng(37.0903563,-95.7829316));
			table.fnDraw();
        });
		// home menu activation
		$('.home').addClass('active');
	
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>